let $document = $(document)

$document.ready((e) => {
    $("#template-header").load("../templates/admin-header.html");
    $("#template-footer").load("../templates/footer.html");
});