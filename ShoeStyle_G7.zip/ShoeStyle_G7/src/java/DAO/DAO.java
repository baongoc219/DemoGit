/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Utils.DBContrext;
import entity.Account;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;

/**
 *
 * @author ASUS
 */
public class DAO {
    Connection conn = null;
    PreparedStatement ptm = null;
    ResultSet rs = null;

    public Account checkExist(String username) {
        try {
            conn = DBContrext.getConnection();
            ptm = conn.prepareStatement("SELECT * FROM [User] WHERE username = ?");
            ptm.setString(1, username);
            rs = ptm.executeQuery();
            while (rs.next()) {
                return new Account(rs.getString(1), 
                        rs.getString(2), 
                        rs.getString(3), 
                        rs.getString(4), 
                        rs.getString(5), 
                        rs.getString(6),
                        rs.getString(7), 
                        rs.getString(8), 
                        rs.getString(9));
            
            }

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
     public Account checkEmailExist(String email) {
      
        try {
             
            conn = DBContrext.getConnection();
            ptm = conn.prepareStatement("SELECT * FROM [User] WHERE email = ?");
            ptm.setString(1, email);
            rs = ptm.executeQuery();
            while (rs.next()) {
                return new Account(rs.getString(1), 
                        rs.getString(2), 
                        rs.getString(3), 
                        rs.getString(4), 
                        rs.getString(5), 
                        rs.getString(6),
                        rs.getString(7), 
                        rs.getString(8), 
                        rs.getString(9));
            
            }

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public boolean SignUp(String username, String fullname, String email, String password,
            String address, Date dob, String phone, String city, String state, String role) {
        try {         
            conn = DBContrext.getConnection();
            ptm = conn.prepareStatement("INSERT INTO [User] VALUES (?,"
                    + "?, "
                    + "?, "
                    + "?, "
                    + "?, ?, ?, "
                    + "?, ?, "
                    + "?)");
            ptm.setString(1, username);
            ptm.setString(2, fullname);
            ptm.setString(3, email);
            ptm.setString(4, password);
            ptm.setString(5, address);
            ptm.setDate(6, (java.sql.Date) dob);
            ptm.setString(7, phone);
            ptm.setString(8, city);
            ptm.setString(9, state);
            ptm.setString(10, role);
            ptm.executeUpdate();
        
        }catch (Exception e){
            
        }
        return true;
    }
    
    
    public Account checkLogin (String username, String password){
        
        try {
            conn =  DBContrext.getConnection();
            ptm = conn.prepareStatement("SELECT * FROM [User] "
                    + "WHERE username = ? AND password = ? ");
            ptm.setString(1,  username );
            ptm.setString(2,  password);
            rs = ptm.executeQuery();
            while(rs.next()){
               return new Account(rs.getString(1),
                       rs.getString(2),
                       rs.getString(3),
                       rs.getString(4),
                       rs.getString(5),
                       rs.getString(6),
                       rs.getString(7),
                       rs.getString(8),
                       rs.getString(9));
            }
        } catch (Exception e) {
        }
       
        return null;
    }
    
}
